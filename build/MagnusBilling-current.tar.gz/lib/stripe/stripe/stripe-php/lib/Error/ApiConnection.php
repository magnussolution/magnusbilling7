<?php

namespace Stripe\Error;

class ApiConnection extends Base
{
}
